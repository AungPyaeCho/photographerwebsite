<?php
    include('connect.php');
?>
<div class="instragram-feed-area owl-carousel">
    <!-- Single Instagram Item -->
    <?php
        $getDataTeam = "select * from team";
        $dataResTeam = mysqli_query($connection, $getDataTeam);
        while ($dataRowTeam = mysqli_fetch_array($dataResTeam, MYSQLI_ASSOC)) 
        {
            echo "<div class='single-instagram-item'>";
                $image = 'admin/' . $dataRowTeam['photo'];
                echo "<img src='" . "../" . $image . "' height='40%' width='40%'alt=''>";
                echo "<div class='instagram-hover-content text-center d-flex align-items-center justify-content-center'>";
                    echo "<a href='https://www.instagram.com/it_is_me_sanuk/'>";
                        echo "<i class='ti-instagram' aria-hidden='true'></i>";
                        echo "<span>" . $dataRowTeam['role'] . "</span>";
                    echo "</a>";
                echo "</div>";
            echo "</div>";
        }
    ?>
</div>
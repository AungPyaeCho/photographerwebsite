

<!-- Single Instagram Item -->
<div class="single-instagram-item">
        <img src="img/bg-img/12.jpg" alt="">
        <div class="instagram-hover-content text-center d-flex align-items-center justify-content-center">
            <a href="#">
                <i class="ti-instagram" aria-hidden="true"></i>
                <span>Alime_photographer</span>
            </a>
        </div>
    </div>
    <!-- Single Instagram Item -->
    <div class="single-instagram-item">
        <img src="img/bg-img/13.jpg" alt="">
        <div class="instagram-hover-content text-center d-flex align-items-center justify-content-center">
            <a href="#">
                <i class="ti-instagram" aria-hidden="true"></i>
                <span>Alime_photographer</span>
            </a>
        </div>
    </div>
    <!-- Single Instagram Item -->
    <div class="single-instagram-item">
        <img src="img/bg-img/14.jpg" alt="">
        <div class="instagram-hover-content text-center d-flex align-items-center justify-content-center">
            <a href="#">
                <i class="ti-instagram" aria-hidden="true"></i>
                <span>Alime_photographer</span>
            </a>
        </div>
    </div>
    <!-- Single Instagram Item -->
    <div class="single-instagram-item">
        <img src="img/bg-img/15.jpg" alt="">
        <div class="instagram-hover-content text-center d-flex align-items-center justify-content-center">
            <a href="#">
                <i class="ti-instagram" aria-hidden="true"></i>
                <span>Alime_photographer</span>
            </a>
        </div>
    </div>
    <!-- Single Instagram Item -->
    <div class="single-instagram-item">
        <img src="img/bg-img/16.jpg" alt="">
        <div class="instagram-hover-content text-center d-flex align-items-center justify-content-center">
            <a href="#">
                <i class="ti-instagram" aria-hidden="true"></i>
                <span>Alime_photographer</span>
            </a>
        </div>
    </div>


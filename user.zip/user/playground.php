<div class='welcome-text'>
                                <h2 data-animation='bounceInDown' data-delay='900ms'>Hello <br>I'm Jackson</h2>
                                <p data-animation='bounceInDown' data-delay='500ms'>I photograph very instinctively. I see how it is taken like that. I do not follow certain styles, philosophies or teachers.</p>
                                <div class='hero-btn-group' data-animation='bounceInDown' data-delay='100ms'>
                                    <a href='#' class='btn alime-btn mb-3 mb-sm-0 mr-4'>Get a Quote</a>
                                    <a class='hero-mail-contact' href='mailto:hello.alime@gmail.com'>hello.alime@gmail.com</a>
                                </div>
                            </div>




               


            <div class='row'>
            <?php
                     $getItem='select * from photo';
                     $itemRes=mysqli_query($connection,$getItem);
                     while($itemRow=mysqli_fetch_array($itemRes,MYSQLI_ASSOC))
                     {
                        echo '<div class='col-12 col-sm-6 col-lg-3 single_gallery_item video human mb-30 wow fadeInUp' data-wow-delay='300ms'>';
                        echo '<div class='single-portfolio-content'>';
                        $image='admin/'.$itemRow['photo'];
                        echo '<img src=src='"."../".$image."' alt=''>';
                        echo '<div class='hover-content'>';
                        echo '<a href=src='"."../".$image."' class='portfolio-img'>+</a>';
                        echo '</div>';
                        echo '</div>';
                        echo '</div>';
                     }
                  ?>
            </div>
            <?php
            $getItem='select * from photo';
            $itemRes=mysqli_query($connection,$getItem);
            while($itemRow=mysqli_fetch_array($itemRes,MYSQLI_ASSOC))
            {
                echo"<div class='col-12 col-sm-6 col-lg-3 single_gallery_item nature mb-30 wow fadeInUp' data-wow-delay='100ms'>";
                    echo"<div class='single-portfolio-content'>";
                    $image='admin/'.$itemRow['photo'];
                    echo"<img src=src='"."../".$image."' alt=''>";
                        echo"<div class='hover-content'>";
                        echo"<a href=src='"."../".$image."' class='portfolio-img'>+</a>";
                        echo"</div>";
                    echo"</div>";
                echo"</div>";
            }
            ?>
            <div class='row'>
            <?php
                     $getItem='select * from backgroundimage';
                     $itemRes=mysqli_query($connection,$getItem);
                     while($itemRow=mysqli_fetch_array($itemRes,MYSQLI_ASSOC))
                     {
                        $image='admin/'.$itemRow['image'];
                        echo '<div class='single-welcome-slide bg-img bg-overlay' style='background-image: url(<?php echo $image?>);'>';
                        echo '<div class='container h-100'>';
                        echo '<div class='row h-100 align-items-center'>';
                        <!-- Welcome Text -->
                        echo '<div class='col-12 col-lg-8 col-xl-6'>';
                            
                        echo '</div>';
                        echo '</div>';
                        echo '</div>';
                        echo '</div>';
                     }
                  ?>
            </div>

            //error ရှိနေ၊ အပြီးမသတ်ခင်စစ်ရန်
    $getItem='select * from backgroundimage';
    $itemRes=mysqli_query($connection,$getItem);
    while($itemRow=mysqli_fetch_array($itemRes,MYSQLI_ASSOC))
    {
        $image='../admin/'.$itemRow['image'];
    }


               <div class='single-welcome-slide bg-img bg-overlay' style='background-image: url(<?php echo $image?>);'>
                <div class='container h-100'>
                    <div class='row h-100 align-items-center'>
                        <!-- Welcome Text -->
                        <div class='col-12 col-lg-8 col-xl-6'>
                            
                        </div>
                    </div>
                </div>
            </div>

            <div class='single-welcome-slide bg-img bg-overlay' style='background-image: url(bgimage/Background3.jpg);'>
                <div class='container h-100'>
                    <div class='row h-100 align-items-center'>
                        <!-- Welcome Text -->
                        <div class='col-12 col-lg-8 col-xl-6'>
                            
                        </div>
                    </div>
                </div>
            </div>

            <div class='single-welcome-slide bg-img bg-overlay' style='background-image: url(bgimage/Background4.jpg);'>
                <div class='container h-100'>
                    <div class='row h-100 align-items-center'>
                        <!-- Welcome Text -->
                        <div class='col-12 col-lg-8 col-xl-6'>
                            
                        </div>
                    </div>
                </div>
            </div>



             <!-- Single Gallery Item -->
             <div class='col-12 col-sm-6 col-lg-3 single_gallery_item nature mb-30 wow fadeInUp' data-wow-delay='100ms'>
                    <div class='single-portfolio-content'>
                        <img src='img/bg-img/3.jpg' alt=''>
                        <div class='hover-content'>
                            <a href='img/bg-img/3.jpg' class='portfolio-img'>+</a>
                        </div>
                    </div>
                </div>

                <!-- Single Gallery Item -->
                <div class='col-12 col-sm-6 col-lg-3 single_gallery_item video human mb-30 wow fadeInUp' data-wow-delay='300ms'>
                    <div class='single-portfolio-content'>
                        <img src='img/bg-img/4.jpg' alt=''>
                        <div class='hover-content'>
                            <a href='img/bg-img/4.jpg' class='portfolio-img'>+</a>
                        </div>
                    </div>
                </div>

                <!-- Single Gallery Item -->
                <div class='col-12 col-sm-6 col-lg-3 single_gallery_item country mb-30 wow fadeInUp' data-wow-delay='500ms'>
                    <div class='single-portfolio-content'>
                        <img src='img/bg-img/5.jpg' alt=''>
                        <div class='hover-content'>
                            <a href='img/bg-img/5.jpg' class='portfolio-img'>+</a>
                        </div>
                    </div>
                </div>

                <!-- Single Gallery Item -->
                <div class='col-12 col-sm-6 col-lg-3 single_gallery_item human mb-30 wow fadeInUp' data-wow-delay='700ms'>
                    <div class='single-portfolio-content'>
                        <img src='img/bg-img/6.jpg' alt=''>
                        <div class='hover-content'>
                            <a href='img/bg-img/6.jpg' class='portfolio-img'>+</a>
                        </div>
                    </div>
                </div>

                <!-- Single Gallery Item -->
                <div class='col-12 col-sm-6 col-lg-3 single_gallery_item nature mb-30 wow fadeInUp' data-wow-delay='100ms'>
                    <div class='single-portfolio-content'>
                        <img src='img/bg-img/7.jpg' alt=''>
                        <div class='hover-content'>
                            <a href='img/bg-img/7.jpg' class='portfolio-img'>+</a>
                        </div>
                    </div>
                </div>

                <!-- Single Gallery Item -->
                <div class='col-12 col-sm-6 col-lg-3 single_gallery_item video country mb-30 wow fadeInUp' data-wow-delay='300ms'>
                    <div class='single-portfolio-content'>
                        <img src='img/bg-img/8.jpg' alt=''>
                        <div class='hover-content'>
                            <a href='img/bg-img/8.jpg' class='portfolio-img'>+</a>
                        </div>
                    </div>
                </div>

                <!-- Single Gallery Item -->
                <div class='col-12 col-sm-6 col-lg-3 single_gallery_item human mb-30 wow fadeInUp' data-wow-delay='500ms'>
                    <div class='single-portfolio-content'>
                        <img src='img/bg-img/10.jpg' alt=''>
                        <div class='hover-content'>
                            <a href='img/bg-img/10.jpg' class='portfolio-img'>+</a>
                        </div>
                    </div>
                </div>

                <!-- Single Gallery Item -->
                <div class='col-12 col-sm-6 col-lg-3 single_gallery_item nature mb-30 wow fadeInUp' data-wow-delay='700ms'>
                    <div class='single-portfolio-content'>
                        <img src='img/bg-img/9.jpg' alt=''>
                        <div class='hover-content'>
                            <a href='img/bg-img/9.jpg' class='portfolio-img'>+</a>
                        </div>
                    </div>
                </div>

                <!-- Single Gallery Item -->
                <div class='col-12 col-sm-6 col-lg-6 single_gallery_item video country mb-30 wow fadeInUp' data-wow-delay='100ms'>
                    <div class='single-portfolio-content'>
                        <img src='img/bg-img/36.jpg' alt=''>
                        <div class='hover-content'>
                            <a href='img/bg-img/36.jpg' class='portfolio-img'>+</a>
                        </div>
                    </div>
                </div>

                <!-- Single Gallery Item -->
                <div class='col-12 col-sm-6 col-lg-3 single_gallery_item human mb-30 wow fadeInUp' data-wow-delay='300ms'>
                    <div class='single-portfolio-content'>
                        <img src='img/bg-img/37.jpg' alt=''>
                        <div class='hover-content'>
                            <a href='img/bg-img/37.jpg' class='portfolio-img'>+</a>
                        </div>
                    </div>
                </div>

                <!-- Single Gallery Item -->
                <div class='col-12 col-sm-6 col-lg-3 single_gallery_item country mb-30 wow fadeInUp' data-wow-delay='500ms'>
                    <div class='single-portfolio-content'>
                        <img src='img/bg-img/5.jpg' alt=''>
                        <div class='hover-content'>
                            <a href='img/bg-img/5.jpg' class='portfolio-img'>+</a>
                        </div>
                    </div>
                </div>



                


                <button class="btn" data-filter=".portrait">Portrait</button>
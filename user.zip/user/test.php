                  
<?php
$getItem='select * from photo';
$itemRes=mysqli_query($connection,$getItem);
while($itemRow=mysqli_fetch_array($itemRes,MYSQLI_ASSOC))
                    echo"<div class='col-12'>";
                    echo"<div class='portfolio-menu text-center'>";    
                    echo"   <button class='btn' data-filter='.landscape'>Lan".$itemRow['album']."dscape</button>";
                    echo"</div>";
                    echo"</div>";
                    echo"</div>";
?>
                    <?php
                  $getItem='select * from photo where album=';
                  $itemRes=mysqli_query($connection,$getItem);
                  while($itemRow=mysqli_fetch_array($itemRes,MYSQLI_ASSOC))
                  {
                    echo" <div class='col-12 col-sm-6 col-lg-3 single_gallery_item country mb-30 wow fadeInUp' data-wow-delay='500ms'>";
                    echo"<div class='single-portfolio-content'>";
                    echo" <img src='img/bg-img/5.jpg' alt=''>";
                    echo"  <div class='hover-content'>";
                    echo"     <a href='img/bg-img/5.jpg' class='portfolio-img'>+</a>";
                    echo"  </div>";
                    echo"</div>";
                    echo" </div>";
                  }
                ?>








<?php
                    $landscape='Landscape';
                    $getItem="select * from photo where orientation='$landscape'";
                    $itemRes=mysqli_query($connection,$getItem);
                     while($itemRow=mysqli_fetch_array($itemRes,MYSQLI_ASSOC))
                     {
                        echo "<div class='col-12 col-sm-6 col-lg-3 single_gallery_item  human mb-30 wow fadeInUp' data-wow-delay='300ms'>";
                        echo "<div class='single-portfolio-content'>";
                        $image='admin/'.$itemRow['photo'];
                        echo "<img src='"."../".$image."' alt=''>";
                        echo "<div class='hover-content'>";
                        echo "<a href='"."../".$image."' class='portfolio-img'>+</a>";
                        echo "</div>";
                        echo "</div>";
                        echo "</div>";
                     }
                ?>

                <?php
                    $portrait='Portrait';
                    $getItem="select * from photo where orientation='$portrait'";
                    $itemRes=mysqli_query($connection,$getItem);
                     while($itemRow=mysqli_fetch_array($itemRes,MYSQLI_ASSOC))
                     {
                        echo "<div class='col-12 col-sm-6 col-lg-3 single_gallery_item portrait human mb-30 wow fadeInUp' data-wow-delay='300ms'>";
                        echo "<div class='single-portfolio-content'>";
                        $image='admin/'.$itemRow['photo'];
                        echo "<img src='"."../".$image."' alt=''>";
                        echo "<div class='hover-content'>";
                        echo "<a href='"."../".$image."' class='portfolio-img'>+</a>";
                        echo "</div>";
                        echo "</div>";
                        echo "</div>";
                     }
                ?>
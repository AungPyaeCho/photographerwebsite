<?php
include('connect.php');
?>

<section class="our-team-area section-padding-80-50">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section-heading text-center wow fadeInUp" data-wow-delay="100ms">
                    <h2>Our Team</h2>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Team Member Area -->
            <?php
                $getDataTeam = "select * from team";
                $dataResTeam = mysqli_query($connection, $getDataTeam);
                while ($dataRowTeam = mysqli_fetch_array($dataResTeam, MYSQLI_ASSOC)) 
                {
                    echo "<div class='col-md-6 col-xl-3'>";
                        echo "<div class='team-content-area text-center mb-30 wow fadeInUp' data-wow-delay='100ms'>";
                            echo "<div class='member-thumb'>";
                                $image = 'admin/' . $dataRowTeam['photo'];
                                echo "<img src='" . "../" . $image . "' width='300' alt=''>";
                            echo "</div>";
                            
                            echo "<h5>" . $dataRowTeam['teammember'] . "</h5>";
                            echo "<span>" . $dataRowTeam['role'] . "</span>";
                            
                            echo "<div class='member-social-info'>";
                                echo "<a href='#'><i class='ti-facebook'></i></a>";
                                echo "<a href='#'><i class='ti-twitter-alt'></i></a>";
                                echo "<a href='#'><i class='ti-linkedin'></i></a>";
                                echo "<a href='#'><i class='ti-pinterest'></i></a>";
                            echo "</div>";
                        echo "</div>";
                    echo "</div>";
                }
            ?>
        </div>
    </div>
</section>
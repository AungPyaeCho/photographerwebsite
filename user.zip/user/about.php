<?php
    include('connect.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title -->
    <title>M | Boudoir Studio</title>

    <!-- Favicon -->

    <!-- Stylesheet -->
    <link rel="stylesheet" href="style.css">
    <link rel='shortcut icon' type='image/x-icon' href='img/core-img/favicon3.png' />
</head>

<body>
    <!-- Preloader -->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- /Preloader -->

    <!-- Top Search Form Area -->
    <div class="top-search-area">
        <div class="modal fade" id="searchModal" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-body">
                        <!-- Close -->
                        <button type="button" class="btn close-btn" data-dismiss="modal"><i class="ti-close"></i></button>
                        <!-- Form -->
                        <form action="index.php" method="post">
                            <input type="search" name="top-search-bar" class="form-control" placeholder="Search and hit enter...">
                            <button type="submit">Search</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Header Area Start -->
    <header class="header-area">
        <!-- Main Header Start -->
        <?php
            include('header.php');
        ?>
    </header>
    <!-- Header Area End -->

    <!-- Breadcrumb Area Start -->
    <section class="breadcrumb-area bg-img bg-overlay jarallax" style="background-image: url(bgimage/Background2.jpg);">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-12">
                    <div class="breadcrumb-content text-center">
                        <h2 class="page-title">About Us</h2>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb justify-content-center">
                                <li class="breadcrumb-item"><a href="index.php"><i class="icon_house_alt"></i> Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">About</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcrumb Area End -->

    <!-- About Us Area Start -->
    <div class="about-us-area section-padding-80-0 clearfix">
        <div class="container">
            <div class="row align-items-center">
                <?php
                $getItem = 'select * from about where aboutid="3" ';
                $itemRes = mysqli_query($connection, $getItem);
                while ($itemRow = mysqli_fetch_array($itemRes, MYSQLI_ASSOC)) 
                {
                    echo "<div class='col-12 col-lg-6'>";
                        echo "<div class='about-us-content mb-80'>";
                            echo "<h3 class='wow fadeInUp' data-wow-delay='100ms'>" . $itemRow['title'] . "</h3>";
                            echo "<div class='line wow fadeInUp' data-wow-delay='200ms'></div>";
                            echo "<p class='wow fadeInUp' data-wow-delay='300ms'>" . $itemRow['description'] . "</p>";
                            echo "<a class='btn alime-btn btn-2 mt-30 wow fadeInUp' data-wow-delay='500ms' href='#'>Contact Us</a>";
                        echo "</div>";
                    echo "</div>";

                    echo "<div class='col-12 col-lg-6'>";
                        echo "<div class='about-video-area mb-80 wow fadeInUp' data-wow-delay='100ms'>";
                            $image = 'admin/' . $itemRow['photo'];
                            echo "<img src='" . "../" . $image . "' alt=''>";
                        echo "</div>";
                    echo "</div>";
                }
                ?>
            </div>
        </div>
    </div>
    <!-- About Us Area End -->

    <!-- Why Choose Us Area Start -->
    <section class="why-choose-us-area bg-gray section-padding-80-0 clearfix">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-heading text-center wow fadeInUp" data-wow-delay="100ms">
                        <h2>Why Choose Us</h2>
                    </div>
                </div>
            </div>

            <div class="row">
                <!-- Single Why Choose Area -->
                <div class="col-md-6 col-lg-4">
                    <div class="why-choose-us-content text-center mb-80 wow fadeInUp" data-wow-delay="100ms">
                        <div class="chosse-us-icon">
                            <i class="fa fa-pencil" aria-hidden="true"></i>
                        </div>
                        <?php
                            $getDataAb2 = "select * from about where aboutid='8'";
                            $dataResAb2 = mysqli_query($connection, $getDataAb2);
                            while ($dataRowAb2 = mysqli_fetch_array($dataResAb2, MYSQLI_ASSOC))
                            {
                                $aboutid2 = $dataRowAb2['aboutid'];
                                $title2 = $dataRowAb2['title'];
                                $description2 = $dataRowAb2['description'];
                            }
                        ?>
                        <h4><?php echo $title2; ?></h4>
                        <p><?php echo $description2; ?></p>
                    </div>
                </div>

                <!-- Single Why Choose Area -->
                <div class="col-md-6 col-lg-4">
                    <div class="why-choose-us-content text-center mb-80 wow fadeInUp" data-wow-delay="300ms">
                        <div class="chosse-us-icon">

                            <i class="fa fa-film" aria-hidden="true"></i>
                        </div>
                        <?php
                            $getDataAb1 = "select * from about where aboutid='6'";
                            $dataResAb1 = mysqli_query($connection, $getDataAb1);
                            while ($dataRowAb1 = mysqli_fetch_array($dataResAb1, MYSQLI_ASSOC))
                            {
                                $aboutid1 = $dataRowAb1['aboutid'];
                                $title1 = $dataRowAb1['title'];
                                $description1 = $dataRowAb1['description'];
                            }
                        ?>
                        <h4><?php echo $title1; ?></h4>
                        <p><?php echo $description1; ?></p>
                    </div>
                </div>

                <!-- Single Why Choose Area -->
                <div class="col-md-6 col-lg-4">
                    <div class="why-choose-us-content text-center mb-80 wow fadeInUp" data-wow-delay="500ms">
                        <div class="chosse-us-icon">
                            <i class="fa fa-camera" aria-hidden="true"></i>
                        </div>
                        <?php
                            $getDataAb3 = "select * from about where aboutid='9'";
                            $dataResAb3 = mysqli_query($connection, $getDataAb3);
                            while ($dataRowAb3 = mysqli_fetch_array($dataResAb3, MYSQLI_ASSOC)) 
                            {
                                $aboutid3 = $dataRowAb3['aboutid'];
                                $title3 = $dataRowAb3['title'];
                                $description3 = $dataRowAb3['description'];
                            }
                        ?>
                        <h4><?php echo $title3; ?></h4>
                        <p><?php echo $description3; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Why Choose  us Area End -->

    <!-- Our Team Area Start -->
    <?php
        include('team.php')
    ?>

    <!-- Our Team Area End -->

    <!-- Follow Area Start -->
    <div class="follow-area clearfix">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-heading text-center">
                        <h2>Follow Instagram</h2>
                        <p>@Alime_photographer</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Instagram Feed Area -->
        <?php
        include('instagram.php')
        ?>
    </div>
    <!-- Follow Area End -->

    <!-- Footer Area Start -->
    <footer class="footer-area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="footer-content d-flex align-items-center justify-content-between">
                        <!-- Copywrite Text -->
                        <div class="copywrite-text">
                            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                                Copyright &copy;<script>
                                    document.write(new Date().getFullYear());
                                </script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
                                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                        </div>
                        <!-- Footer Logo -->
                        <div class="footer-logo">
                            <a href="#"><img src="img/core-img/logo2.png" alt=""></a>
                        </div>
                        <!-- Social Info -->
                        <div class="social-info">
                            <a href="#"><i class="ti-facebook" aria-hidden="true"></i></a>
                            <a href="#"><i class="ti-twitter-alt" aria-hidden="true"></i></a>
                            <a href="#"><i class="ti-linkedin" aria-hidden="true"></i></a>
                            <a href="#"><i class="ti-pinterest" aria-hidden="true"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Area End -->

    <!-- **** All JS Files ***** -->
    <!-- jQuery 2.2.4 -->
    <script src="js/jquery.min.js"></script>
    <!-- Popper -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap -->
    <script src="js/bootstrap.min.js"></script>
    <!-- All Plugins -->
    <script src="js/alime.bundle.js"></script>
    <!-- Active -->
    <script src="js/default-assets/active.js"></script>

</body>

</html>
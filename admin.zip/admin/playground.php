<?php
if(isset($_POST['formWheelchair']) && 
$_POST['formWheelchair'] == 'Yes') 
{
    echo '<script>alert('Yes'); </script>';
}
else
{
    echo '<script>alert('No'); </script>';
}	 
?>


<!DOCTYPE html>
<html lang='en'>


<!-- blank.html  21 Nov 2019 03:54:41 GMT -->
<head>
    <meta charset='UTF-8'>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no' name='viewport'>
    <title>mboudoir - Admin</title>
  
    <!-- General CSS Files -->
    <link rel='stylesheet' href='assets/css/app.min.css'>
    
    <!-- Template CSS -->
    <link rel='stylesheet' href='assets/css/style.css'>
    <link rel='stylesheet' href='assets/css/components.css'>
    
    <!-- Custom style CSS -->
    <link rel='stylesheet' href='assets/css/custom.css'>
    <link rel='shortcut icon' type='image/x-icon' href='assets/img/favicon.png' />
</head>

<body>
    <div class='loader'></div>
        <div id='app'>
            <div class='main-wrapper main-wrapper-1'>
                <div class='navbar-bg'></div>
                    <nav class='navbar navbar-expand-lg main-navbar sticky'>
                        <div class='form-inline mr-auto'>

                        </div>
                    </nav>
                    
                    <!-- sidebar -->
                    <?php
                        include('navbar.php');
                    ?>
                    
                    <!-- Main Content -->
      
                    <div class='main-content'>
                        <section class='section'>
                            <div class='section-body'>
                                
                                <!-- add content here -->
                                <div class='card'>
                                    <div class='card-body'>
                                        <h5 class='card-title'>Playground</h5>
                                            <form action='playground.php' method='post'>
                                            Testing ?
                                            <input type='checkbox' name='formWheelchair' value='Yes' />
                                            <input type='submit' name='formSubmit' value='Submit' />
                                        </form>
                                    </div>
                                </div>  
            
                                
                            </div>
                        </section>       
                    </div>
      
                    <footer class='main-footer'>
                
                        <div class='footer-left'>
                            <a href='templateshub.net'>Templateshub</a></a>
                        </div>
        
                        <div class='footer-right'>
                        </div>
                    </footer>
                </div>
            </div>
        </div>
    </div>
    

    <!-- General JS Scripts -->
    <script src='assets/js/app.min.js'></script>
    
    <!-- JS Libraies -->
    <!-- Page Specific JS File -->
    <!-- Template JS File -->
  
    <script src='assets/js/scripts.js'></script>

    <!-- Custom JS File -->
    <script src='assets/js/custom.js'></script>
</body>


<!-- blank.html  21 Nov 2019 03:54:41 GMT -->
</html>

if($showFront=='Yes'){
                                                    echo '<input type='checkbox' name='showFront' id='showFront' checked='True' value='Yes'/>';
                                                }
                                                else
                                                {
                                                    echo '<input type='checkbox' name='showFront' checked='No' value='No'  id='showFront'/>';
                                                }


                                                
                                                
<html>
<head>
<title>PHP File Upload example</title>
</head>
<body>

<form action='fileupload.php' enctype='multipart/form-data' method='post'>
Select image :
<input type='file' name='file'><br/>
<input type='submit' value='Upload' name='Submit1'> <br/>


</form>
<?php
if(isset($_POST['Submit1']))
{ 
$filepath = 'images/' . $_FILES['file']['name'];

if(move_uploaded_file($_FILES['file']['tmp_name'], $filepath)) 
{
echo '<img src='.$filepath.' height=200 width=300 />';
} 
else 
{
echo 'Error !!';
}
} 
?>

</body>
</html>

<?PHP

$imagePath = 'images/your_image.png';

list($oldWidth, $height, $type, $attr) = getimagesize($image_path); 

$percentChange = $newWidth / $oldWidth;
$newHeight = round( ( $percentChange *$height ) );

echo '<img src=''.$imagePath.'' height=''.$new_height.'' width=''.$newWidth.''>';

?> 
<?php
list($width, $height) = getimagesize('path/to/your/image.jpg');

if( $width > $height)
    $orientation = 'landscape';
else
    $orientation = 'portrait';
?>


<input type='submit' value='Upload Photo' name='btnUploadImage'>
                                                <?php
                                                    if(isset($_POST['btnUploadImage']))
                                                    { 
                                                        $filetemp=$_FILES['image']['tmp_name'];
                                                        $filename=$_FILES['image']['name'];
                                                        $filetype=$_FILES['image']['type'];
                                                        $filepath='image/'.$filename;
                                                        move_uploaded_file($filetemp,$filepath);
                                                        //echo '<img src=''.$filepath.'' class='image_1'>';
                                                        //if(move_uploaded_file($filetemp,$filepath)) 
                                                        //{
                                                        //    echo '<img src='.$filepath.' height=200 width=300 />';
                                                        //} 
                                                        //else 
                                                        //{
                                                       // echo 'Error !!';
                                                        //} 
                                                    } 
                                                ?>

<?php
$getItem="select * from photo where orientation='Portrait'";
$itemRes=mysqli_query($connection,$getItem);
while($itemRow=mysqli_fetch_array($itemRes,MYSQLI_ASSOC))
{
    echo"<div class="grid-item">";
                                        
                                      
echo"<figure class='effect-ruby'>";
$image='admin/'.$itemRow['photo'];
echo "<img src='"."../".$image."' alt='Image' class='img-fluid tm-img'>";
echo"<figcaption>";
echo"<h2 class='tm-figure-title'>".$itemRow['photoname']."></h2>";
echo"<p class='tm-figure-description'></p>";
echo"<a href='img/tm-img-01.jpg'>View more</a>";
echo"</figcaption>";           
echo"</figure>";
echo"</div>";
}
?>


<?php
                                                        $getItem="select * from photo where orientation='Portrait'";
                                                        $itemRes=mysqli_query($connection,$getItem);
                                                        while($itemRow=mysqli_fetch_array($itemRes,MYSQLI_ASSOC))
                                                        {
                                                            echo "<div class='col-lg-3 col-sm-6'>";
                                                            echo "<div class='gallery'>";
                                                            //to retrive id
                                                            $photoId=$itemRow['photoid'];
                              
                                                            echo "<h4 class='bursh_text'>".$itemRow['photoname']."</h4>";
                                                            //echo "<p class='lorem_text'>".$itemRow['album']."</p>";
                               
                                                            //to retrive image form different path
                                                            $image='admin/'.$itemRow['photo'];
                                                            echo "<img src='"."../".$image."' class='gallery' style='width:400px'>";
                                                            echo "<div class='btn_main'>";
                                                            echo "<div class='buy_bt'>";
                                                            echo "<ul>";
                                                            echo "<li class='active'><a href='#'>Delete</a></li>";
                                                            echo "<li><a href='photoEdit.php?photoid=$photoId'>Update</a></li>";
                                                            echo "</ul>";
                                                            echo "</div>";
                                                            //echo "<h3 class='price_text'>".$itemRow['category']."</h3>";
                                                            echo "</div>";
                                                            echo "</div>";
                                                            echo "</div>";  
                                                        }
                                                    ?>
<div class="main-sidebar sidebar-style-2">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="index.php"> <img alt="image" src="assets/img/favicon.png" class="header-logo" /> <span
                class="logo-name">mBoudoir</span>
            </a>
        </div>
        <ul class="sidebar-menu">
        <li class="menu-header">Main</li>
            <li class="dropdown">
                <a href="aboutEntry.php" class="nav-link"><i data-feather="monitor"></i><span>About</span></a>
                <a href="albumEntry.php" class="nav-link"><i data-feather="monitor"></i><span>Album</span></a>
                <a href="categoryEntry.php" class="nav-link"><i data-feather="monitor"></i><span>Category</span></a>
                <a href="orientationEntry.php" class="nav-link"><i data-feather="monitor"></i><span>Orientation</span></a>
                <a href="photoEntry.php" class="nav-link"><i data-feather="monitor"></i><span>Photo Entry</span></a>
                <a href="photoEntryBg.php" class="nav-link"><i data-feather="monitor"></i><span>Photo Entry (Background Photo)</span></a>
                <a href="photoGalleryLandscape.php" class="nav-link"><i data-feather="monitor"></i><span>Photo Gallery (Landscape)</span></a>
                <a href="photoGalleryPortrait.php" class="nav-link"><i data-feather="monitor"></i><span>Photo Gallery (Portrait)</span></a>   
                <a href="teamEntry.php" class="nav-link"><i data-feather="monitor"></i><span>Team</span></a>    
            </li>
          </ul>
    </aside>
</div>
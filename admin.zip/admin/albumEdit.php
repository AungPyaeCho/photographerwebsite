<?php
    //connect to connection-string page
    include('connect.php');

    //check if showfront check box is checked or not 
    //if checked then set showfront to Yes else set showfront to No
    if(isset($_POST['showFront']))
    {
        $showFront='Yes';
    }
    else
    {
        $showFront='No';
    }
    
     //received id to retrive data from database 
    $albumid=$_GET['albumid'];

    //received function to delete or update data
    $function=$_GET['function'];

     //delete function
    if($function=='delete')
    {
        $delete="delete from album where albumid='$albumid'";
        mysqli_query($connection,$delete);
        header('location:albumEntry.php');
    }

    //update function to retrive data and fill to form
    if($function=='update')
    {
        $getData="select * from album where albumid='$albumid'";
        $dataRes=mysqli_query($connection,$getData);
        
        //fetch data from database, looping and add to variables
        while($dataRow=mysqli_fetch_array($dataRes,MYSQLI_ASSOC))
        {
            $albumid=$dataRow['albumid'];
            $albumName=$dataRow['albumname'];
            $description=$dataRow['description'];
            $showFront=$dataRow['showfront'];
        }
    }

    //update function to update data
    if(isset($_POST['btnUpdate']))
    {
        //receiving data form text fields using post method
        $albumid=$_POST['albumid'];
        $albumName=$_POST['albumName'];
        $description=$_POST['description'];

        //update query string to update data
        $updateAlubmTable="update album set albumname='$albumName',description='$description',showfront='$showFront' where albumid='$albumid'";
        
        //execute query
        mysqli_query($connection,$updateAlubmTable);
        
        //go back to relate main page
        header('location:albumEntry.php');
    }
?>

<!DOCTYPE html>
<html lang="en">


<!-- blank.html  21 Nov 2019 03:54:41 GMT -->
<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
    <title>mboudoir - Admin</title>
  
    <!-- General CSS Files -->
    <link rel="stylesheet" href="assets/css/app.min.css">
    
    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/components.css">
    
    <!-- Custom style CSS -->
    <link rel="stylesheet" href="assets/css/custom.css">
    <link rel='shortcut icon' type='image/x-icon' href='assets/img/favicon.png' />
</head>

<body>
    <div class="loader"></div>
        <div id="app">
            <div class="main-wrapper main-wrapper-1">
                <div class="navbar-bg"></div>
                    <nav class="navbar navbar-expand-lg main-navbar sticky">
                        <div class="form-inline mr-auto">
                            <ul class="navbar-nav mr-3">
                                <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg collapse-btn"> <i data-feather="align-justify"></i></a></li>
                                    <li><a href="#" class="nav-link nav-link-lg fullscreen-btn"> <i data-feather="maximize"> </i></a></li>
                                <li>
                                    <form class="form-inline mr-auto">
                                        <div class="search-element">
                                            <input class="form-control" type="search" placeholder="Search" aria-label="Search" data-width="200">
                                            <button class="btn" type="submit">
                                            <i class="fas fa-search"></i>
                                            </button>
                                        </div>
                                    </form>
                                </li>
                            </ul>
                        </div>

                        <ul class="navbar-nav navbar-right">
                            <li class="dropdown dropdown-list-toggle"><a href="#" data-toggle="dropdown" class="nav-link nav-link-lg message-toggle"><i data-feather="mail"></i>
                                <span class="badge headerBadge1">   </span></a>
            
                                <div class="dropdown-menu dropdown-list dropdown-menu-right pullDown">
                                    <div class="dropdown-header">
                                        Messages
                                        <div class="float-right">
                                            <a href="#">Mark All As Read</a>
                                        </div>
                                    </div>
                                    
                                    <div class="dropdown-list-content dropdown-list-message">
                                    </div>
                                    
                                    <div class="dropdown-footer text-center">
                                        <a href="#">View All <i class="fas fa-chevron-right"></i></a>
                                    </div>
                                </div>
                            </li>
            
                            <li class="dropdown dropdown-list-toggle"><a href="#" data-toggle="dropdown" class="nav-link notification-toggle nav-link-lg"><i data-feather="bell" class="bell"></i></a>
            
                                <div class="dropdown-menu dropdown-list dropdown-menu-right pullDown">
                                    <div class="dropdown-header">
                                        Notifications
                                        <div class="float-right">
                                            <a href="#">Mark All As Read</a>
                                        </div>
                                    </div>
                                
                                    <div class="dropdown-list-content dropdown-list-icons">
                                    </div>
                            
                                    <div class="dropdown-footer text-center">
                                        <a href="#">View All <i class="fas fa-chevron-right"></i></a>
                                    </div>
                                </div>
                            </li>
                            
                            <li class="dropdown"><a href="#" data-toggle="dropdown" class="nav-link dropdown-toggle nav-link-lg nav-link-user"> <img alt="image" src="assets/img/user.png" class="user-img-radious-style"> <span class="d-sm-none d-lg-inline-block"></span></a>
            
                                <div class="dropdown-menu dropdown-menu-right pullDown">
                                    <div class="dropdown-title"> Hello Sarah Smith </div>
                                        
                                    <a href="profile.html" class="dropdown-item has-icon"> <i class="far fa-user"></i> Profile </a>
                                        
                                    <a href="timeline.html" class="dropdown-item has-icon"> <i class="fas fa-bolt"></i> Activities </a> 
                                        
                                    <a href="#" class="dropdown-item has-icon"> <i class="fas fa-cog"></i> Settings </a>
                                        
                                    <div class="dropdown-divider"></div>
              
                                    <a href="auth-login.html" class="dropdown-item has-icon text-danger"> <i class="fas fa-sign-out-alt"></i> Logout </a>
                                </div>    
                            </li>
                        </ul>
                    </nav>
                    
                    <!-- sidebar -->
                    <?php
                        include('navbar.php');
                    ?>
                    
                    <!-- Main Content -->
      
                    <div class="main-content">
                        <section class="section">
                            <div class="section-body">
                                
                                <!-- add content here -->
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title">Album</h5>
                                        <form action="albumEdit.php" method="post">
                                        <div class="form-group">
                                            <label for="albumName">Album Name</label>
                                                <input type="text" name="albumid" id="albumid" value='<?php echo $albumid;?>' hidden>
                                                <input type="text" name="albumName" id="albumName" class="form-control" value='<?php echo $albumName;?>' required>
                                            </div>
                                            <div class = "form-group">
                                                <label for="description">Description</label>
                                                <textarea class="form-control" name="description" id="description"><?php echo $description;?></textarea>
                                            </di>
                                            <div class = "form-group">
                                                <label for="showFront">Showfront</label>
                                            </di>
                                            <div class = "form-group">
                                                Yes
                                                <input type="checkbox" name="showFront" value="Yes" <?php if($showFront=="Yes") echo "checked";?> >
                                            </div>          
                                            <div class="form-group">
                                                <input type="submit" name="btnUpdate" value="Update" class="btn btn-primary" >
                                            </div>
                                        </form>
                                    </div>
                                </div>  
            
                                <div class="card">
                                    <div class="card-body">
                                    <h5 class="card-title">Photo Category</h5>
                                         <div class='table'>
                                         <table class='table responsive'>
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Album Name</th>
                                                        <th>Description</th>
                                                        <th>Show Front</th>
                                                        <th>Update</th>
                                                        <th>Delete</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $getData="select * from album";
                                                    $getDataRes=mysqli_query($connection,$getData);
                                                    while($dataRow=mysqli_fetch_array($getDataRes,MYSQLI_ASSOC)){
                                                    echo "<tr>";
                                                        echo "<td>";
                                                            $albumid=$dataRow['albumid'];
                                                            echo $dataRow['albumid'];                    
                                                        echo "</td>";
                                
                                                        echo"<td>";
                                                            echo $dataRow['albumname'];
                                                        echo"</td>";

                                                        echo"<td>";
                                                            echo $dataRow['description'];
                                                        echo"</td>";
                          
                                                        echo"<td>";
                                                            echo $dataRow['showfront'];
                                                        echo"</td>";
                          
                                                        echo "<td>";
                                                            echo "<a href='albumEdit.php?albumid=$albumid&function=update' class='btn btn-primary'>";
                                                            echo "Update";
                                                            echo "</a>";
                                                        echo "</td>";
                                
                                                        echo "<td>";
                                                            echo "<a href='albumEdit.php?albumid=$albumid&function=delete' class='btn btn-primary'>";
                                                            echo "Delete";
                                                            echo "</a>";
                                                        echo "</td>";
                                                    echo "</tr>";
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
        
                        <div class="settingSidebar">
                            <a href="javascript:void(0)" class="settingPanelToggle"> <i class="fa fa-spin fa-cog"></i></a>
                            <div class="settingSidebar-body ps-container ps-theme-default">
                                <div class=" fade show active">
                                    <div class="setting-panel-header"> Setting Panel </div>
              
                                    <div class="p-15 border-bottom">
                                        <h6 class="font-medium m-b-10">Select Layout</h6>
                                        <div class="selectgroup layout-color w-50">
                                            <label class="selectgroup-item">
                                                <input type="radio" name="value" value="1" class="selectgroup-input-radio select-layout" checked>
                                                <span class="selectgroup-button">Light</span>
                                            </label>
                                            <label class="selectgroup-item">
                                                <input type="radio" name="value" value="2" class="selectgroup-input-radio select-layout">
                                                <span class="selectgroup-button">Dark</span>
                                            </label>
                                        </div>                        
                                    </div>
              
                                    <div class="p-15 border-bottom">
                                        <h6 class="font-medium m-b-10">Sidebar Color</h6>
                                        <div class="selectgroup selectgroup-pills sidebar-color">
                                            <label class="selectgroup-item">
                                                <input type="radio" name="icon-input" value="1" class="selectgroup-input select-sidebar">
                                                <span class="selectgroup-button selectgroup-button-icon" data-toggle="tooltip" data-original-title="Light Sidebar"><i class="fas fa-sun"></i></span>
                                            </label>
                                                
                                            <label class="selectgroup-item">
                                                <input type="radio" name="icon-input" value="2" class="selectgroup-input select-sidebar" checked>
                                                <span class="selectgroup-button selectgroup-button-icon" data-toggle="tooltip" data-original-title="Dark Sidebar"><i class="fas fa-moon"></i></span>
                                            </label>
                                        </div>
                                    </div>
              
                                    <div class="p-15 border-bottom">
                                        <h6 class="font-medium m-b-10">Color Theme</h6>
                                        <div class="theme-setting-options">
                                            <ul class="choose-theme list-unstyled mb-0">
                                                <li title="white" class="active">
                                                    <div class="white"></div>
                                                </li>
                                                <li title="cyan">
                                                    <div class="cyan"></div>
                                                </li>
                                                <li title="black">
                                                    <div class="black"></div>
                                                </li>
                                                <li title="purple">
                                                    <div class="purple"></div>
                                                </li>
                                                <li title="orange">
                                                    <div class="orange"></div>
                                                </li>
                                                <li title="green">
                                                    <div class="green"></div>
                                                </li>
                                                <li title="red">
                                                    <div class="red"></div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
            
                                    <div class="p-15 border-bottom">
                                        <div class="theme-setting-options">
                                        <label class="m-b-0">
                                            <input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input" id="mini_sidebar_setting">
                                            <span class="custom-switch-indicator"></span>
                                            <span class="control-label p-l-10">Mini Sidebar</span>
                                        </label>
                                        </div>
                                    </div>
            
                                    <div class="p-15 border-bottom">
                                        <div class="theme-setting-options">
                                            <label class="m-b-0">
                                                <input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input" id="sticky_header_setting">
                                                <span class="custom-switch-indicator"></span>
                                                <span class="control-label p-l-10">Sticky Header</span>
                                            </label>
                                        </div>
                                    </div>
            
                                    <div class="mt-4 mb-4 p-3 align-center rt-sidebar-last-ele">
                                        <a href="#" class="btn btn-icon icon-left btn-primary btn-restore-theme">
                                        <i class="fas fa-undo"></i> Restore Default
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
      
                    <footer class="main-footer">
                
                        <div class="footer-left">
                            <a href="templateshub.net">Templateshub</a></a>
                        </div>
        
                        <div class="footer-right">
                        </div>
                    </footer>
                </div>
            </div>
        </div>
    </div>
    

    <!-- General JS Scripts -->
    <script src="assets/js/app.min.js"></script>
    
    <!-- JS Libraies -->
    <!-- Page Specific JS File -->
    <!-- Template JS File -->
  
    <script src="assets/js/scripts.js"></script>

    <!-- Custom JS File -->
    <script src="assets/js/custom.js"></script>

    <script>
        
    </script> 
</body>


<!-- blank.html  21 Nov 2019 03:54:41 GMT -->
</html>
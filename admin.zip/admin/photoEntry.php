<?php
    //connect to connection-string page
    include('connect.php');
    
    //save function to save data to database
    if(isset($_POST['btnSave']))
    {
        //check if showfront check box is checked or not 
        //if checked then set showfront to Yes else set showfront to No
        if(isset($_POST['showFront']))
        {
            $showFront='Yes';
        }
        else
        {
            $showFront='No';
        }

        //receiving data form text fields using post method
        $photoName=$_POST['photoName'];
        $photoCategory=$_POST['photoCategory'];
        $description=$_POST['description'];
        $orientation=$_POST['orientation'];
        $album=$_POST['album'];
  
        //check file name, file type, tmporary name and path
        $filetemp=$_FILES['imgPhoto']['tmp_name'];
        $filename=$_FILES['imgPhoto']['name'];
        $filetype=$_FILES['imgPhoto']['type'];

        //file path
        $filepath='image/'.$filename;

        //uploadfile to folder
        move_uploaded_file($filetemp,$filepath);

        //query to insert data into photo table
        $insertIntoPhotoTable="insert into photo(photoname, photocategory, photo, description, orientation, showfront, album)value
        ('$photoName','$photoCategory','$filepath','$description','$orientation','$showFront','$album')";
        
        //execute query
        mysqli_query($connection,$insertIntoPhotoTable);

        //go back to current page
        header('location:photoEntry.php');
    }
?>

<!DOCTYPE html>
<html lang="en">


<!-- blank.html  21 Nov 2019 03:54:41 GMT -->
<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
    <title>mboudoir - Admin</title>
  
    <!-- General CSS Files -->
    <link rel="stylesheet" href="assets/css/app.min.css">
    
    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/components.css">
    
    <!-- Custom style CSS -->
    <link rel="stylesheet" href="assets/css/custom.css">
    <link rel='shortcut icon' type='image/x-icon' href='assets/img/favicon.png' />
</head>

<body>
    <div class="loader"></div>
        <div id="app">
            <div class="main-wrapper main-wrapper-1">
                <div class="navbar-bg"></div>
                    <nav class="navbar navbar-expand-lg main-navbar sticky">
                        <div class="form-inline mr-auto">
                            <ul class="navbar-nav mr-3">
                                <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg collapse-btn"> <i data-feather="align-justify"></i></a></li>
                                    <li><a href="#" class="nav-link nav-link-lg fullscreen-btn"> <i data-feather="maximize"> </i></a></li>
                                <li>
                                    <form class="form-inline mr-auto">
                                        <div class="search-element">
                                            <input class="form-control" type="search" placeholder="Search" aria-label="Search" data-width="200">
                                            <button class="btn" type="submit">
                                            <i class="fas fa-search"></i>
                                            </button>
                                        </div>
                                    </form>
                                </li>
                            </ul>
                        </div>

                        <ul class="navbar-nav navbar-right">
                            <li class="dropdown dropdown-list-toggle"><a href="#" data-toggle="dropdown" class="nav-link nav-link-lg message-toggle"><i data-feather="mail"></i>
                                <span class="badge headerBadge1">   </span></a>
            
                                <div class="dropdown-menu dropdown-list dropdown-menu-right pullDown">
                                    <div class="dropdown-header">
                                        Messages
                                        <div class="float-right">
                                            <a href="#">Mark All As Read</a>
                                        </div>
                                    </div>
                                    
                                    <div class="dropdown-list-content dropdown-list-message">
                                    </div>
                                    
                                    <div class="dropdown-footer text-center">
                                        <a href="#">View All <i class="fas fa-chevron-right"></i></a>
                                    </div>
                                </div>
                            </li>
            
                            <li class="dropdown dropdown-list-toggle"><a href="#" data-toggle="dropdown" class="nav-link notification-toggle nav-link-lg"><i data-feather="bell" class="bell"></i></a>
            
                                <div class="dropdown-menu dropdown-list dropdown-menu-right pullDown">
                                    <div class="dropdown-header">
                                        Notifications
                                        <div class="float-right">
                                            <a href="#">Mark All As Read</a>
                                        </div>
                                    </div>
                                
                                    <div class="dropdown-list-content dropdown-list-icons">
                                    </div>
                            
                                    <div class="dropdown-footer text-center">
                                        <a href="#">View All <i class="fas fa-chevron-right"></i></a>
                                    </div>
                                </div>
                            </li>
                            
                            <li class="dropdown"><a href="#" data-toggle="dropdown" class="nav-link dropdown-toggle nav-link-lg nav-link-user"> <img alt="image" src="assets/img/user.png" class="user-img-radious-style"> <span class="d-sm-none d-lg-inline-block"></span></a>
            
                                <div class="dropdown-menu dropdown-menu-right pullDown">
                                    <div class="dropdown-title"> Hello Sarah Smith </div>
                                        
                                    <a href="profile.html" class="dropdown-item has-icon"> <i class="far fa-user"></i> Profile </a>
                                        
                                    <a href="timeline.html" class="dropdown-item has-icon"> <i class="fas fa-bolt"></i> Activities </a> 
                                        
                                    <a href="#" class="dropdown-item has-icon"> <i class="fas fa-cog"></i> Settings </a>
                                        
                                    <div class="dropdown-divider"></div>
              
                                    <a href="auth-login.html" class="dropdown-item has-icon text-danger"> <i class="fas fa-sign-out-alt"></i> Logout </a>
                                </div>    
                            </li>
                        </ul>
                    </nav>
                    
                    <!-- sidebar -->
                    <?php
                        include('navbar.php');
                    ?>
                    
                    <!-- Main Content -->
      
                    <div class="main-content">
                        <section class="section">
                            <div class="section-body">
                                
                                <!-- add content here -->
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title">Photo Entry</h5>
                                        <form action="photoEntry.php" enctype="multipart/form-data" method="post">
                                            <div class="form-group">
                                                <label for="photoName">Photo Name </label>
                                                <input type="text" name="photoName" id="photoName" class="form-control" required>
                                            </div>

                                            <div class="form-group">
                                                <label for="photoCategory">Photo Category</label>
                                                <select name="photoCategory" class="form-control">
                                                <?php
                                                    $getTypeCategory="select * from photocategory";
                                                    $typeResCategory=mysqli_query($connection,$getTypeCategory);
                                                    echo "<option selected>";
                                                    echo "Select Category";
                                                    echo "</option>";
                                                    while($typeRowCategory=mysqli_fetch_array($typeResCategory,MYSQLI_ASSOC)){
                                                        echo "<option>";
                                                            echo $typeRowCategory['category'];
                                                        echo "</option>";
                                                    }
                                                ?>
                                                </select>
                                            </div>

                                            <div class="form-group">
                                                <label for="orientation">Orientation</label>
                                                <select name="orientation" class="form-control">
                                                <?php
                                                    $getTypeOrientation = "select * from orientation";
                                                    $typeResOrientation = mysqli_query($connection, $getTypeOrientation);
                                                    echo "<option selected>";
                                                    echo "Select Orientation";
                                                    echo "</option>";
                                                    while ($typeRowOrientation = mysqli_fetch_array($typeResOrientation, MYSQLI_ASSOC)) {
                                                        echo "<option>";
                                                            echo $typeRowOrientation['orientation'];
                                                        echo "</option>";
                                                    }
                                                ?>  
                                                </select>
                                            </div>
                                           
                                            <div class="form-group">
                                                <label for="album">Album</label>
                                                <select name="album" class="form-control">
                                                <?php
                                                    $getTypeAlbum = "select * from album";
                                                    $typeResAlbum = mysqli_query($connection, $getTypeAlbum);
                                                    echo "<option selected>";
                                                    echo "Select Album Name";
                                                    echo "</option>";
                                                    while ($typeRowAlbum = mysqli_fetch_array($typeResAlbum, MYSQLI_ASSOC)) {
                                                        echo "<option>";
                                                            echo $typeRowAlbum['albumname'];
                                                        echo "</option>";
                                                    }
                                                    ?>
                                                </select>
                                            </div>

                                            <div class="form-group">
                                                <label for="description">Description</label>
                                                <textarea name="description" id="description" class="form-control"></textarea>
                                            </div>

                                            <div class="form-group">
                                                <label for="orientation">Showfront</label>
                                            </div>
                                            <div class = "form-group">
                                                Yes
                                                <input type="checkbox" name="showFront" id="showFront" value="Yes" />
                                            </div>
                                            
                                            <div class="form-group">
                                                <label for="imgPhoto">Image</label>
                                                <input type="file" name="imgPhoto" id="imgPhoto" class="form-control" required>
                                            </div>

                                            <div class="form-group">
                                                <input type="submit" name="btnSave" value="Save" class="btn btn-primary">
                                            </div>
                                        </form>
                                    </div>
                                </div>  
            
                                <div class="card">
                                    <div class="card-body">
                                    <h5 class="card-title">Album</h5>
                                         <div class='table'>
                                            <table class='table responsive'>
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Photo</th>
                                                        <th>Photo Name</th>
                                                        <th>Photo Category</th>
                                                        <th>Orientation</th>
                                                        <th>Album</th>
                                                        <th>Show Front</th>
                                                        <th>Description</th>
                                                        <th>Album</th>
                                                        <th>Update</th>
                                                        <th>Delete</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $getData="select * from photo";
                                                    $getDataRes=mysqli_query($connection,$getData);
                                                    while($dataRow=mysqli_fetch_array($getDataRes,MYSQLI_ASSOC)){
                                                    echo "<tr>";
                                                        echo "<td>";
                                                            $photoid=$dataRow['photoid'];
                                                            echo $dataRow['photoid'];                    
                                                        echo "</td>";
                                                        
                                                        echo "<td>";
                                                            $imgPhoto=$dataRow['photo'];
                                                            echo "<img src='$imgPhoto'  class='img-thumbnail' style='width:200px;'>";
                                                        echo "</td>";

                                                        echo"<td>";
                                                            echo $dataRow['photoname'];
                                                        echo"</td>";

                                                        echo"<td>";
                                                            echo $dataRow['album'];
                                                        echo"</td>";

                                                        echo"<td>";
                                                            echo $dataRow['photocategory'];
                                                        echo"</td>";

                                                        echo"<td>";
                                                            echo $dataRow['description'];
                                                        echo"</td>";

                                                        echo"<td>";
                                                            echo $dataRow['orientation'];
                                                        echo"</td>";

                                                        echo"<td>";
                                                            echo $dataRow['showfront'];
                                                        echo"</td>";

                                                        echo"<td>";
                                                            echo $dataRow['album'];
                                                        echo"</td>";
                          
                                                        echo "<td>";
                                                            echo "<a href='photoEdit.php?photoid=$photoid&function=update' class='btn btn-primary'>";
                                                            echo "Update";
                                                            echo "</a>";
                                                        echo "</td>";
                                
                                                        echo "<td>";
                                                            echo "<a href='photoEdit.php?photoid=$photoid&function=delete' class='btn btn-primary'>";
                                                            echo "Delete";
                                                            echo "</a>";
                                                        echo "</td>";
                                                    echo "</tr>";
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
        
                        <div class="settingSidebar">
                            <a href="javascript:void(0)" class="settingPanelToggle"> <i class="fa fa-spin fa-cog"></i></a>
                            <div class="settingSidebar-body ps-container ps-theme-default">
                                <div class=" fade show active">
                                    <div class="setting-panel-header"> Setting Panel </div>
              
                                    <div class="p-15 border-bottom">
                                        <h6 class="font-medium m-b-10">Select Layout</h6>
                                        <div class="selectgroup layout-color w-50">
                                            <label class="selectgroup-item">
                                                <input type="radio" name="value" value="1" class="selectgroup-input-radio select-layout" checked>
                                                <span class="selectgroup-button">Light</span>
                                            </label>
                                            <label class="selectgroup-item">
                                                <input type="radio" name="value" value="2" class="selectgroup-input-radio select-layout">
                                                <span class="selectgroup-button">Dark</span>
                                            </label>
                                        </div>                        
                                    </div>
              
                                    <div class="p-15 border-bottom">
                                        <h6 class="font-medium m-b-10">Sidebar Color</h6>
                                        <div class="selectgroup selectgroup-pills sidebar-color">
                                            <label class="selectgroup-item">
                                                <input type="radio" name="icon-input" value="1" class="selectgroup-input select-sidebar">
                                                <span class="selectgroup-button selectgroup-button-icon" data-toggle="tooltip" data-original-title="Light Sidebar"><i class="fas fa-sun"></i></span>
                                            </label>
                                                
                                            <label class="selectgroup-item">
                                                <input type="radio" name="icon-input" value="2" class="selectgroup-input select-sidebar" checked>
                                                <span class="selectgroup-button selectgroup-button-icon" data-toggle="tooltip" data-original-title="Dark Sidebar"><i class="fas fa-moon"></i></span>
                                            </label>
                                        </div>
                                    </div>
              
                                    <div class="p-15 border-bottom">
                                        <h6 class="font-medium m-b-10">Color Theme</h6>
                                        <div class="theme-setting-options">
                                            <ul class="choose-theme list-unstyled mb-0">
                                                <li title="white" class="active">
                                                    <div class="white"></div>
                                                </li>
                                                <li title="cyan">
                                                    <div class="cyan"></div>
                                                </li>
                                                <li title="black">
                                                    <div class="black"></div>
                                                </li>
                                                <li title="purple">
                                                    <div class="purple"></div>
                                                </li>
                                                <li title="orange">
                                                    <div class="orange"></div>
                                                </li>
                                                <li title="green">
                                                    <div class="green"></div>
                                                </li>
                                                <li title="red">
                                                    <div class="red"></div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
            
                                    <div class="p-15 border-bottom">
                                        <div class="theme-setting-options">
                                        <label class="m-b-0">
                                            <input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input" id="mini_sidebar_setting">
                                            <span class="custom-switch-indicator"></span>
                                            <span class="control-label p-l-10">Mini Sidebar</span>
                                        </label>
                                        </div>
                                    </div>
            
                                    <div class="p-15 border-bottom">
                                        <div class="theme-setting-options">
                                            <label class="m-b-0">
                                                <input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input" id="sticky_header_setting">
                                                <span class="custom-switch-indicator"></span>
                                                <span class="control-label p-l-10">Sticky Header</span>
                                            </label>
                                        </div>
                                    </div>
            
                                    <div class="mt-4 mb-4 p-3 align-center rt-sidebar-last-ele">
                                        <a href="#" class="btn btn-icon icon-left btn-primary btn-restore-theme">
                                        <i class="fas fa-undo"></i> Restore Default
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
      
                    <footer class="main-footer">
                
                        <div class="footer-left">
                            <a href="templateshub.net">Templateshub</a></a>
                        </div>
        
                        <div class="footer-right">
                        </div>
                    </footer>
                </div>
            </div>
        </div>
    </div>
    

    <!-- General JS Scripts -->
    <script src="assets/js/app.min.js"></script>
    
    <!-- JS Libraies -->
    <!-- Page Specific JS File -->
    <!-- Template JS File -->
  
    <script src="assets/js/scripts.js"></script>

    <!-- Custom JS File -->
    <script src="assets/js/custom.js"></script>
</body>


<!-- blank.html  21 Nov 2019 03:54:41 GMT -->
</html>
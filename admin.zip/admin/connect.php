<?php
    //session start
    session_start();

    //host name
    $host='localhost';

    //user name and password
    $user='root';
    $pass='';

    //database name
    $database='mboudoir_db';

    //connection string
    $connection=mysqli_connect($host,$user,$pass)or die('Error in connection');

    //execute 
    mysqli_select_db($connection,$database);
?>